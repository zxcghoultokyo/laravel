<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <div class="pull-right">
        <button type="submit" form="form-cfsp" data-toggle="tooltip" title="<?php echo $button_save; ?>" class="btn btn-primary"><i class="fa fa-save"></i></button>
        <a href="<?php echo $cancel; ?>" data-toggle="tooltip" title="<?php echo $button_cancel; ?>" class="btn btn-default"><i class="fa fa-reply"></i></a>
      </div>
      <h1><?php echo $heading_title; ?></h1>
      <ul class="breadcrumb">
        <?php foreach ($breadcrumbs as $breadcrumb) { ?>
        <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
  <div class="container-fluid">
    <?php if ($error_warning) { ?>
    <div class="alert alert-danger alert-dismissible"><i class="fa fa-exclamation-circle"></i> <?php echo $error_warning; ?>
      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
    <?php } ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> <?php echo $text_edit; ?></h3>
      </div>
      <div class="panel-body">
        <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" id="form-cfsp" class="form-horizontal">
          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-status"><?php echo $entry_status; ?></label>
            <div class="col-sm-10">
              <select name="cfsp_status" id="input-status" class="form-control">
                <?php if ($cfsp_status) { ?>
                <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                <option value="0"><?php echo $text_disabled; ?></option>
                <?php } else { ?>
                <option value="1"><?php echo $text_enabled; ?></option>
                <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>
          <div class="form-group<?php echo !empty($error_threshold) ? ' has-error' : ''; ?>">
            <label class="col-sm-2 control-label" for="input-threshold"><?php echo $entry_threshold; ?></label>
            <div class="col-sm-10">
              <input type="text" name="cfsp_threshold" value="<?php echo $cfsp_threshold; ?>" placeholder="20000" id="input-threshold" class="form-control" />
              <?php if (!empty($error_threshold)) { ?>
              <div class="text-danger"><?php echo $error_threshold; ?></div>
              <?php } ?>
              <p class="help-block"><?php echo $help_threshold; ?></p>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-currency"><?php echo $entry_currency_label; ?></label>
            <div class="col-sm-10">
              <input type="text" name="cfsp_currency_label" value="<?php echo $cfsp_currency_label; ?>" placeholder="грн" id="input-currency" class="form-control" />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-text-before"><?php echo $entry_text_before; ?></label>
            <div class="col-sm-10">
              <textarea name="cfsp_text_before" rows="3" id="input-text-before" class="form-control"><?php echo htmlspecialchars($cfsp_text_before, ENT_QUOTES, 'UTF-8'); ?></textarea>
              <p class="help-block"><?php echo $help_placeholders; ?></p>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-text-after"><?php echo $entry_text_after; ?></label>
            <div class="col-sm-10">
              <textarea name="cfsp_text_after" rows="2" id="input-text-after" class="form-control"><?php echo htmlspecialchars($cfsp_text_after, ENT_QUOTES, 'UTF-8'); ?></textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-success"><?php echo $entry_success_text; ?></label>
            <div class="col-sm-10">
              <textarea name="cfsp_success_text" rows="2" id="input-success" class="form-control"><?php echo htmlspecialchars($cfsp_success_text, ENT_QUOTES, 'UTF-8'); ?></textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-allow-html"><?php echo $entry_allow_html; ?></label>
            <div class="col-sm-10">
              <select name="cfsp_allow_html" id="input-allow-html" class="form-control">
                <?php if ($cfsp_allow_html) { ?>
                <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                <option value="0"><?php echo $text_disabled; ?></option>
                <?php } else { ?>
                <option value="1"><?php echo $text_enabled; ?></option>
                <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                <?php } ?>
              </select>
              <p class="help-block"><?php echo $help_allow_html; ?></p>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php echo $footer; ?>
