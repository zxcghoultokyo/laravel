<?php
class ControllerExtensionModuleCfsp extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/cfsp');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('cfsp', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
        }

        // Texts
        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');

        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_threshold'] = $this->language->get('entry_threshold');
        $data['entry_currency_label'] = $this->language->get('entry_currency_label');
        $data['entry_text_before'] = $this->language->get('entry_text_before');
        $data['entry_text_after'] = $this->language->get('entry_text_after');
        $data['entry_ship_time'] = $this->language->get('entry_ship_time');
        $data['entry_success_text'] = $this->language->get('entry_success_text');
        $data['entry_allow_html'] = $this->language->get('entry_allow_html');

        $data['help_placeholders'] = $this->language->get('help_placeholders');
        $data['help_threshold'] = $this->language->get('help_threshold');
        $data['help_allow_html'] = $this->language->get('help_allow_html');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        // Errors
        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['threshold'])) {
            $data['error_threshold'] = $this->error['threshold'];
        } else {
            $data['error_threshold'] = '';
        }

        // Breadcrumbs
        $data['breadcrumbs'] = array();
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
        );
        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/cfsp', 'token=' . $this->session->data['token'], true)
        );

        $data['action'] = $this->url->link('extension/module/cfsp', 'token=' . $this->session->data['token'], true);
        $data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);

        // Values
        $fields = array(
            'cfsp_status' => 0,
            'cfsp_threshold' => 20000,
            'cfsp_currency_label' => 'грн',
            'cfsp_text_before' => 'Замов ще на <b>{remaining}</b> <sup>{currency}</sup> та отримай безкоштовну доставку',
            'cfsp_text_after' => 'Відправимо сьогодні о <b>19:00</b>',
            'cfsp_success_text' => 'Безкоштовна доставка активована! 🎉',
            'cfsp_allow_html' => 1
        );

        foreach ($fields as $key => $default) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif ($this->config->get($key) !== null) {
                $data[$key] = $this->config->get($key);
            } else {
                $data[$key] = $default;
            }
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/cfsp', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/cfsp')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        $threshold = isset($this->request->post['cfsp_threshold']) ? $this->request->post['cfsp_threshold'] : 0;
        if (!is_numeric($threshold) || (float)$threshold < 0) {
            $this->error['threshold'] = $this->language->get('error_threshold');
        }

        return !$this->error;
    }
}
