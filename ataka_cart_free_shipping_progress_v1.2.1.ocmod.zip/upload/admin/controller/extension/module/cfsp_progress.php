<?php
class ControllerExtensionModuleCfspProgress extends Controller {
    private $error = array();

    public function index() {
        $this->load->language('extension/module/cfsp_progress');
        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
            $this->model_setting_setting->editSetting('cfsp_progress', $this->request->post);
            $this->session->data['success'] = $this->language->get('text_success');
            $this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true));
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_edit'] = $this->language->get('text_edit');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');

        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_threshold'] = $this->language->get('entry_threshold');
        $data['entry_line1'] = $this->language->get('entry_line1');
        $data['entry_line2'] = $this->language->get('entry_line2');
        $data['entry_time'] = $this->language->get('entry_time');

        $data['help_placeholders'] = $this->language->get('help_placeholders');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_extension'),
            'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/module/cfsp_progress', 'token=' . $this->session->data['token'], true)
        );

        $data['action'] = $this->url->link('extension/module/cfsp_progress', 'token=' . $this->session->data['token'], true);
        $data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);

        // Values
        $keys = array(
            'cfsp_progress_status',
            'cfsp_progress_threshold',
            'cfsp_progress_line1',
            'cfsp_progress_line2',
            'cfsp_progress_time'
        );

        foreach ($keys as $k) {
            if (isset($this->request->post[$k])) {
                $data[$k] = $this->request->post[$k];
            } else {
                $data[$k] = $this->config->get($k);
            }
        }

        if ($data['cfsp_progress_threshold'] === null || $data['cfsp_progress_threshold'] === '') {
            $data['cfsp_progress_threshold'] = 20000;
        }
        if (!$data['cfsp_progress_line1']) {
            $data['cfsp_progress_line1'] = 'Замов ще на <b>{remaining}</b> та отримай безкоштовну доставку';
        }
        if (!$data['cfsp_progress_line2']) {
            $data['cfsp_progress_line2'] = 'Відправимо сьогодні о <b>{time}</b>';
        }
        if (!$data['cfsp_progress_time']) {
            $data['cfsp_progress_time'] = '19:00';
        }

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('extension/module/cfsp_progress', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'extension/module/cfsp_progress')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }
        return !$this->error;
    }
}
