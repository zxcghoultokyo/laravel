<?php
$_['heading_title']       = 'ATK Free Shipping Progress v2';
$_['text_extension']      = 'Розширення';
$_['text_success']        = 'Налаштування збережено!';
$_['text_edit']           = 'Редагування';
$_['entry_status']        = 'Статус';
$_['entry_threshold']     = 'Поріг (сума)';
$_['entry_currency_label']= 'Валюта';
$_['entry_text_before']   = 'Текст (до порогу)';
$_['entry_text_after']    = 'Другий рядок';
$_['entry_success_text']  = 'Текст успіху';
$_['entry_allow_html']    = 'Дозволити HTML';
$_['help_placeholders']   = '{remaining}, {threshold}, {total}, {currency}';
$_['help_threshold']      = 'Наприклад: 20000';
$_['error_permission']    = 'Немає прав!';
$_['error_threshold']     = 'Поріг має бути числом >= 0';
