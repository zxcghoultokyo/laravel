<?php
$_['heading_title']    = 'Прогрес безкоштовної доставки (попап кошика)';
$_['text_extension']   = 'Розширення';
$_['text_success']     = 'Налаштування збережено!';
$_['text_edit']        = 'Налаштування модуля';

$_['entry_status']     = 'Статус';
$_['entry_threshold']  = 'Поріг безкоштовної доставки (грн)';
$_['entry_time']       = 'Час відправки (наприклад 19:00)';
$_['entry_line1']      = 'Текст 1 (можна HTML)';
$_['entry_line2']      = 'Текст 2 (можна HTML)';

$_['help_placeholders']        = 'Доступні плейсхолдери: {remaining}, {threshold}, {total}, {time}';

$_['error_permission'] = 'У вас немає прав для керування модулем!';
