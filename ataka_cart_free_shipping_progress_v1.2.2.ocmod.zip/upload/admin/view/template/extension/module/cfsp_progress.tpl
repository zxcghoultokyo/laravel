<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <div class="pull-right">
        <button type="submit" form="form-cfsp" data-toggle="tooltip" title="<?php echo $button_save; ?>" class="btn btn-primary"><i class="fa fa-save"></i></button>
        <a href="<?php echo $cancel; ?>" data-toggle="tooltip" title="<?php echo $button_cancel; ?>" class="btn btn-default"><i class="fa fa-reply"></i></a>
      </div>
      <h1><?php echo $heading_title; ?></h1>
      <ul class="breadcrumb">
        <?php foreach ($breadcrumbs as $breadcrumb) { ?>
          <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
  <div class="container-fluid">
    <?php if ($error_warning) { ?>
      <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?php echo $error_warning; ?>
        <button type="button" class="close" data-dismiss="alert">&times;</button>
      </div>
    <?php } ?>
    <div class="panel panel-default">
      <div class="panel-heading"><h3 class="panel-title"><i class="fa fa-pencil"></i> <?php echo $text_edit; ?></h3></div>
      <div class="panel-body">
        <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" id="form-cfsp" class="form-horizontal">
          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-status"><?php echo $entry_status; ?></label>
            <div class="col-sm-10">
              <select name="cfsp_progress_status" id="input-status" class="form-control">
                <?php if ($cfsp_progress_status) { ?>
                  <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                  <option value="0"><?php echo $text_disabled; ?></option>
                <?php } else { ?>
                  <option value="1"><?php echo $text_enabled; ?></option>
                  <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-threshold"><?php echo $entry_threshold; ?></label>
            <div class="col-sm-10">
              <input type="text" name="cfsp_progress_threshold" value="<?php echo $cfsp_progress_threshold; ?>" placeholder="20000" id="input-threshold" class="form-control" />
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-time"><?php echo $entry_time; ?></label>
            <div class="col-sm-10">
              <input type="text" name="cfsp_progress_time" value="<?php echo $cfsp_progress_time; ?>" placeholder="19:00" id="input-time" class="form-control" />
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-line1"><?php echo $entry_line1; ?></label>
            <div class="col-sm-10">
              <textarea name="cfsp_progress_line1" rows="3" id="input-line1" class="form-control"><?php echo $cfsp_progress_line1; ?></textarea>
              <p class="help-block"><?php echo $help_placeholders; ?></p>
            </div>
          </div>

          <div class="form-group">
            <label class="col-sm-2 control-label" for="input-line2"><?php echo $entry_line2; ?></label>
            <div class="col-sm-10">
              <textarea name="cfsp_progress_line2" rows="3" id="input-line2" class="form-control"><?php echo $cfsp_progress_line2; ?></textarea>
              <p class="help-block"><?php echo $help_placeholders; ?></p>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
<?php echo $footer; ?>
