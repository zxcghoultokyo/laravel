<?php
// Heading
$_['heading_title']       = 'Прогрес безкоштовної доставки (попап)';

// Text
$_['text_extension']      = 'Розширення';
$_['text_success']        = 'Налаштування модуля збережено!';
$_['text_edit']           = 'Налаштування модуля';

// Entry
$_['entry_status']        = 'Статус';
$_['entry_threshold']     = 'Поріг безкоштовної доставки';
$_['entry_currency_label']= 'Позначення валюти';
$_['entry_text_before']   = 'Текст (до досягнення порогу)';
$_['entry_text_after']    = 'Другий рядок тексту';
$_['entry_ship_time']     = 'Час відправки';
$_['entry_success_text']  = 'Текст успіху (поріг досягнуто)';
$_['entry_allow_html']    = 'Дозволити HTML';

// Help
$_['help_placeholders']   = 'Плейсхолдери: {remaining} - залишок, {threshold} - поріг, {total} - сума, {currency} - валюта';
$_['help_threshold']      = 'Сума в основній валюті магазину (наприклад 20000)';
$_['help_allow_html']     = 'Дозволяє теги: b, strong, sup, br, span';

// Error
$_['error_permission']    = 'У вас немає прав для зміни цього модуля!';
$_['error_threshold']     = 'Поріг має бути числом більше або рівним 0!';
