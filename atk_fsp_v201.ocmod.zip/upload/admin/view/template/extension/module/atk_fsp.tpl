<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <div class="pull-right">
        <button type="submit" form="form-atk-fsp" data-toggle="tooltip" title="<?php echo $button_save; ?>" class="btn btn-primary"><i class="fa fa-save"></i></button>
        <a href="<?php echo $cancel; ?>" data-toggle="tooltip" title="<?php echo $button_cancel; ?>" class="btn btn-default"><i class="fa fa-reply"></i></a>
      </div>
      <h1><?php echo $heading_title; ?></h1>
      <ul class="breadcrumb">
        <?php foreach ($breadcrumbs as $breadcrumb) { ?>
        <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
  <div class="container-fluid">
    <?php if ($error_warning) { ?>
    <div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> <?php echo $error_warning; ?><button type="button" class="close" data-dismiss="alert">&times;</button></div>
    <?php } ?>
    <div class="panel panel-default">
      <div class="panel-heading"><h3 class="panel-title"><i class="fa fa-pencil"></i> <?php echo $text_edit; ?></h3></div>
      <div class="panel-body">
        <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" id="form-atk-fsp" class="form-horizontal">
          <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $entry_status; ?></label>
            <div class="col-sm-10">
              <select name="atk_fsp_status" class="form-control">
                <option value="1"<?php echo $atk_fsp_status ? ' selected' : ''; ?>><?php echo $text_enabled; ?></option>
                <option value="0"<?php echo !$atk_fsp_status ? ' selected' : ''; ?>><?php echo $text_disabled; ?></option>
              </select>
            </div>
          </div>
          <div class="form-group<?php echo $error_threshold ? ' has-error' : ''; ?>">
            <label class="col-sm-2 control-label"><?php echo $entry_threshold; ?></label>
            <div class="col-sm-10">
              <input type="text" name="atk_fsp_threshold" value="<?php echo $atk_fsp_threshold; ?>" placeholder="20000" class="form-control" />
              <?php if ($error_threshold) { ?><div class="text-danger"><?php echo $error_threshold; ?></div><?php } ?>
              <p class="help-block"><?php echo $help_threshold; ?></p>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $entry_currency_label; ?></label>
            <div class="col-sm-10">
              <input type="text" name="atk_fsp_currency_label" value="<?php echo $atk_fsp_currency_label; ?>" placeholder="грн" class="form-control" />
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $entry_text_before; ?></label>
            <div class="col-sm-10">
              <textarea name="atk_fsp_text_before" rows="3" class="form-control"><?php echo htmlspecialchars($atk_fsp_text_before, ENT_QUOTES, 'UTF-8'); ?></textarea>
              <p class="help-block"><?php echo $help_placeholders; ?></p>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $entry_text_after; ?></label>
            <div class="col-sm-10">
              <textarea name="atk_fsp_text_after" rows="2" class="form-control"><?php echo htmlspecialchars($atk_fsp_text_after, ENT_QUOTES, 'UTF-8'); ?></textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $entry_success_text; ?></label>
            <div class="col-sm-10">
              <textarea name="atk_fsp_success_text" rows="2" class="form-control"><?php echo htmlspecialchars($atk_fsp_success_text, ENT_QUOTES, 'UTF-8'); ?></textarea>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-2 control-label"><?php echo $entry_allow_html; ?></label>
            <div class="col-sm-10">
              <select name="atk_fsp_allow_html" class="form-control">
                <option value="1"<?php echo $atk_fsp_allow_html ? ' selected' : ''; ?>><?php echo $text_enabled; ?></option>
                <option value="0"<?php echo !$atk_fsp_allow_html ? ' selected' : ''; ?>><?php echo $text_disabled; ?></option>
              </select>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<?php echo $footer; ?>
