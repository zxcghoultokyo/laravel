<?php
/**
 * ATK Free Shipping Progress Widget
 * Standalone controller - works without OCMOD
 * Version 2.1.0
 */
class ControllerExtensionModuleAtkFspWidget extends Controller {
    
    public function index() {
        // Check if module is enabled
        $status = $this->config->get('module_atk_fsp_status');
        if (!$status) {
            return '';
        }
        
        // Load cart
        $this->load->model('setting/setting');
        
        // Get settings
        $threshold = (float)$this->config->get('module_atk_fsp_threshold');
        if ($threshold <= 0) {
            $threshold = 20000;
        }
        
        // Get cart subtotal in BASE currency (usually USD)
        $subtotal_base = $this->cart->getSubTotal();
        
        // Convert to current display currency
        $currency_code = $this->session->data['currency'];
        $subtotal = $this->currency->convert($subtotal_base, $this->config->get('config_currency'), $currency_code);
        
        // Fallback: if subtotal seems too low (still in USD), multiply by rate
        // This happens if convert() doesn't work properly
        if ($subtotal < 100 && $subtotal_base > 0 && $threshold > 1000) {
            // Get currency rate from DB
            $this->load->model('localisation/currency');
            $currency_info = $this->model_localisation_currency->getCurrencyByCode($currency_code);
            if ($currency_info && $currency_info['value'] > 1) {
                $subtotal = $subtotal_base * $currency_info['value'];
            }
        }
        
        // Calculate remaining
        $remaining = $threshold - $subtotal;
        if ($remaining < 0) {
            $remaining = 0;
        }
        
        // Calculate percentage
        $percent = ($subtotal / $threshold) * 100;
        if ($percent > 100) {
            $percent = 100;
        }
        
        // Format values
        $subtotal_fmt = $this->currency->format($subtotal, $currency_code, '', false);
        $remaining_fmt = $this->currency->format($remaining, $currency_code, '', false);
        $threshold_fmt = $this->currency->format($threshold, $currency_code, '', false);
        
        // Get texts from settings
        $lang_code = $this->config->get('config_language_id');
        
        $text_progress = $this->config->get('module_atk_fsp_text_progress');
        if (empty($text_progress)) {
            $text_progress = 'До безкоштовної доставки залишилось <b>{remaining}</b>';
        }
        
        $text_achieved = $this->config->get('module_atk_fsp_text_achieved');
        if (empty($text_achieved)) {
            $text_achieved = 'Вітаємо! Ви отримали <b>безкоштовну доставку!</b>';
        }
        
        // Prepare display text
        if ($remaining > 0) {
            $display_text = str_replace(
                ['{remaining}', '{total}', '{threshold}'],
                [$remaining_fmt, $subtotal_fmt, $threshold_fmt],
                $text_progress
            );
        } else {
            $display_text = $text_achieved;
        }
        
        // Determine color class
        if ($percent >= 100) {
            $color_class = 'atk-fsp-success';
        } elseif ($percent >= 70) {
            $color_class = 'atk-fsp-warning';
        } else {
            $color_class = 'atk-fsp-danger';
        }
        
        // Build HTML
        $html = '
        <div class="atk-fsp-container" style="padding: 10px; margin: 10px 0; background: #f9f9f9; border-radius: 8px;">
            <div class="atk-fsp-text" style="margin-bottom: 8px; font-size: 13px; color: #333;">
                ' . html_entity_decode($display_text, ENT_QUOTES, 'UTF-8') . '
            </div>
            <div class="atk-fsp-bar-wrapper" style="background: #e0e0e0; border-radius: 10px; height: 12px; overflow: hidden;">
                <div class="atk-fsp-bar ' . $color_class . '" style="width: ' . round($percent) . '%; height: 100%; border-radius: 10px; transition: width 0.5s; background: ' . ($percent >= 100 ? '#28a745' : ($percent >= 70 ? '#ffc107' : '#dc3545')) . ';"></div>
            </div>
            <div class="atk-fsp-debug" style="font-size: 10px; color: #999; margin-top: 5px;">
                ' . round($subtotal) . ' / ' . round($threshold) . ' (' . round($percent) . '%)
            </div>
        </div>';
        
        return $html;
    }
    
    // AJAX endpoint
    public function getProgress() {
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode([
            'html' => $this->index(),
            'success' => true
        ]));
    }
}
