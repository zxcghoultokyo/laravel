<?php
$_['heading_title']       = 'ATK Free Shipping Progress v2';
$_['text_extension']      = 'Расширения';
$_['text_success']        = 'Настройки сохранены!';
$_['text_edit']           = 'Редактирование';
$_['entry_status']        = 'Статус';
$_['entry_threshold']     = 'Порог (сумма)';
$_['entry_currency_label']= 'Валюта';
$_['entry_text_before']   = 'Текст (до порога)';
$_['entry_text_after']    = 'Вторая строка';
$_['entry_success_text']  = 'Текст успеха';
$_['entry_allow_html']    = 'Разрешить HTML';
$_['help_placeholders']   = '{remaining}, {threshold}, {total}, {currency}';
$_['help_threshold']      = 'Например: 20000';
$_['error_permission']    = 'Нет прав!';
$_['error_threshold']     = 'Порог должен быть >= 0';
