<?php
// Heading
$_['heading_title']       = 'Прогресс бесплатной доставки (попап)';

// Text
$_['text_extension']      = 'Расширения';
$_['text_success']        = 'Настройки модуля сохранены!';
$_['text_edit']           = 'Настройки модуля';

// Entry
$_['entry_status']        = 'Статус';
$_['entry_threshold']     = 'Порог бесплатной доставки';
$_['entry_currency_label']= 'Обозначение валюты';
$_['entry_text_before']   = 'Текст (до достижения порога)';
$_['entry_text_after']    = 'Вторая строка текста';
$_['entry_ship_time']     = 'Время отправки';
$_['entry_success_text']  = 'Текст успеха (порог достигнут)';
$_['entry_allow_html']    = 'Разрешить HTML';

// Help
$_['help_placeholders']   = 'Плейсхолдеры: {remaining} - остаток, {threshold} - порог, {total} - сумма, {currency} - валюта';
$_['help_threshold']      = 'Сумма в основной валюте магазина (например 20000)';
$_['help_allow_html']     = 'Разрешает теги: b, strong, sup, br, span';

// Error
$_['error_permission']    = 'У вас нет прав для изменения этого модуля!';
$_['error_threshold']     = 'Порог должен быть числом больше или равным 0!';
